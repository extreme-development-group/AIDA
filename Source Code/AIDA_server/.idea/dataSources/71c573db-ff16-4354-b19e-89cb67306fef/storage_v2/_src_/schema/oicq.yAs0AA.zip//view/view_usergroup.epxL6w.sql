create view view_usergroup as
select `oicq`.`dw_group`.`group_id`     AS `group_id`,
       `oicq`.`dw_group`.`group_name`   AS `group_name`,
       `oicq`.`dw_group`.`group_avatar` AS `group_avatar`,
       `oicq`.`dw_group`.`group_trades` AS `group_trades`,
       `oicq`.`dw_usergroup`.`user_id`  AS `user_id`
from `oicq`.`dw_group`
         join `oicq`.`dw_usergroup`
where (`oicq`.`dw_group`.`group_id` = `oicq`.`dw_usergroup`.`group_id`);


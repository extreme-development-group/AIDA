create view view_useruser as
select `oicq`.`dw_useruser`.`myself`   AS `myself`,
       `oicq`.`dw_useruser`.`myfriend` AS `myfriend`,
       `oicq`.`dw_user`.`user_name`    AS `user_name`,
       `oicq`.`dw_user`.`user_avatar`  AS `user_avatar`,
       `oicq`.`dw_user`.`user_trades`  AS `user_trades`
from `oicq`.`dw_user`
         join `oicq`.`dw_useruser`
where (`oicq`.`dw_user`.`user_id` = `oicq`.`dw_useruser`.`myfriend`)
order by `oicq`.`dw_useruser`.`myself`;

